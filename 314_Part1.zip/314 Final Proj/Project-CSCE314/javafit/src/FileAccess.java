// Write code to load the workouts from the provided workouts.csv file. The function should return a Workouts object.
import java.io.IOException;
import java.io.File;
import java.util.Scanner;

//import Workouts.Muscle;

public class FileAccess {
  
  public static Workouts loadWorkouts() {
	  Workouts wk = new Workouts();
	  String[] singleWorkout = new String[6];
	  try {
	  File file = new File(Config.WORKOUTFILE);
	  Scanner scanner = new Scanner(file);
	  while (scanner.hasNextLine()) {
		  String line = scanner.nextLine();
		  singleWorkout = line.split(",");
		  wk.addWorkout(singleWorkout[0], Workouts.Equipment.valueOf(singleWorkout[1]), Workouts.Muscle.valueOf(singleWorkout[2]), Workouts.Muscle.valueOf(singleWorkout[3]), singleWorkout[4], singleWorkout[5]); 
	  }
	  scanner.close(); 
	  } catch (IOException e) {
		  e.printStackTrace();
	  }
	  return wk;
	  // What is a try/catch block and why do we need one?
    // What is an exception?
  }
}
  
